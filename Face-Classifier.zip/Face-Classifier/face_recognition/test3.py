import cv2 
img = cv2.imread('test_pho1')